#! /bin/sh

exit 0

NETINI="/mnt/mtd/ipc/conf/config_net.ini"

webport=`grep httpport $NETINI | awk -F "\"" '{print $2}'`

killall mdns

NETFLAG=`cat /mnt/mtd/ipc/tmpfs/netflag.dat`
if [ $NETFLAG -eq 0 ]
then
	ETHNM="eth0"
else
	ETHNM="ra0"
fi

NAME=`ifconfig $ETHNM | awk '/inet/{print $2}'| awk -F: '{print $2}'`
NAME="IPCAM-$NAME"
/mnt/mtd/ipc/mdns -n "$NAME" -t _http._tcp -p $webport -b &
