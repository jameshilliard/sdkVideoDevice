#! /bin/sh

exit 0

MAPINI="/mnt/mtd/ipc/conf/config_sysinfo.ini"
MACINI="/mnt/mtd/ipc/conf/config_priv.ini"
NETINI="/mnt/mtd/ipc/conf/config_net.ini"
TYPE="H3-187V"

webport=`grep httpport $NETINI | awk -F "\"" '{print $2}'` 
uenable=`grep udenable $MAPINI | awk -F "\"" '{print $2}'`  

NETFLAG=`cat /mnt/mtd/ipc/tmpfs/netflag.dat`
if [ $NETFLAG -eq 0 ]
then
	mac=`ifconfig eth0 | grep HWaddr | awk -F " " '{print $5}'`
	dev=eth0
else
	mac=`ifconfig ra0 | grep HWaddr | awk -F " " '{print $5}'`
	dev=ra0
fi

killall upnpd
sleep 1
killall upnpd
route del -net 239.0.0.0 netmask 255.0.0.0 eth0
route del -net 239.0.0.0 netmask 255.0.0.0 ra0

if [ $uenable -eq 1 ]
then
    /mnt/mtd/ipc/upnpd -i $dev -P $webport -w /mnt/mtd/ipc/conf -n $TYPE-$mac
    route add -net 239.0.0.0 netmask 255.0.0.0 $dev
fi
