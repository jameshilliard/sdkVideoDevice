#include "oss_config.h"

const char TEST_OSS_HOST[] = "<oss host>";
const int TEST_OSS_PORT = 80;
const char TEST_ACCESS_KEY_ID[] = "<Please apply your access key id>";
const char TEST_ACCESS_KEY_SECRET[] = "<Please apply your access key secret>";
const char TEST_BUCKET_NAME[] = "<Please apply your bucket>";
