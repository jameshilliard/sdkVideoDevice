#include "oss_config.h"

const char OSS_HOST[] = "<oss host>";
const int OSS_PORT = 80;
const char ACCESS_KEY_ID[] = "<Please apply your access key id>";
const char ACCESS_KEY_SECRET[] = "<Please apply your access key secret>";
const char BUCKET_NAME[] = "<Please apply your bucket>";
const char MULTIPART_UPLOAD_FILE_PATH[] = "<Please apply your multipart upload file>";

