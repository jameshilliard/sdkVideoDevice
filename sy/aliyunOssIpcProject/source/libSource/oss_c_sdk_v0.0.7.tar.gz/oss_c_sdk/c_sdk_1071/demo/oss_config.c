#include "oss_config.h"

const char TEST_OSS_HOST[] = "<oss host>";
const int TEST_OSS_PORT = 80;
const char TEST_ACCESS_ID[] = "<Please apply your access id>";
const char TEST_ACCESS_KEY[] = "<Please apply your access key>";
const char TEST_BUCKET_NAME[] = "<Please apply your bucket>";
