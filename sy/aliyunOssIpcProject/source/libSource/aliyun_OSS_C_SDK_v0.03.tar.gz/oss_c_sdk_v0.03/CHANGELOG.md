v0.0.1
2015-05-28
    基于OSS API文档，提供OSS bucket、object以及multipart相关的常见操作API
    提供基于CuTest的sample

v0.0.2
2015-06-10
    增加oss_upload_part_copy，支持Upload Part Copy方式拷贝
    增加sts服务临时授权方式访问OSS

v0.0.3
2015-07-08
    增加oss_append_object_from_buffer接口，支持追加上传buffer中的内容到object
    增加oss_append_object_from_file接口，支持追加上传文件中的内容到object
