#ifndef OSS_TEST_UTIL_H
#define OSS_TEST_UTIL_H

#include "CuTest.h"
#include "utf8proc.h"
#include "aos_http_io.h"
#include "aos_string.h"
#include "aos_transport.h"
#include "oss_define.h"

OSS_CPP_START

#define oss_utf8_encode_error_status_set(STATUS, RES) do {          \
    aos_status_set(STATUS, RES, AOS_UTF8_ENCODE_ERROR_CODE, NULL);  \
    } while(0)

#define test_object_base() do {                                         \
        s = aos_status_create(options->pool);                           \
        aos_str_set(&bucket, bucket_name);                              \
        len = strlen(object_name);                                      \
        ret = oss_utf8_encode(&utf8_object_name, object_name, len);     \
        if (ret != AOSE_OK) {                                           \
            oss_utf8_encode_error_status_set(s, AOSE_UTF8_ENCODE_ERROR);\
            return s;                                                   \
        }                                                               \
        aos_str_set(&object, utf8_object_name);                         \
        resp_headers = aos_table_make(options->pool, 5);                \
    } while(0)

void make_rand_string(aos_pool_t *p, int len, aos_string_t *data);

aos_buf_t *make_random_buf(aos_pool_t *p, int len);

void make_random_body(aos_pool_t *p, int count, aos_list_t *bc);

void init_test_config(oss_config_t *config, int is_oss_domain);

void init_test_request_options(oss_request_options_t *options, int is_oss_domain);

aos_status_t * create_test_bucket(const oss_request_options_t *options,
    const char *bucket_name, oss_acl_e oss_acl);

aos_status_t *create_test_object(const oss_request_options_t *options, const char *bucket_name, 
    const char *object_name, const char *data, aos_table_t *headers);

aos_status_t *create_test_object_from_file(const oss_request_options_t *options, const char *bucket_name,
    const char *object_name, const char *filename, aos_table_t *headers);

aos_status_t *delete_test_object(const oss_request_options_t *options,
    const char *bucket_name, const char *object_name);

aos_status_t *init_test_multipart_upload(const oss_request_options_t *options, const char *bucket_name, 
    const char *object_name, aos_string_t *upload_id);

aos_status_t *abort_test_multipart_upload(const oss_request_options_t *options, const char *bucket_name,
    const char *object_name, aos_string_t *upload_id);

char *gen_test_signed_url(const oss_request_options_t *options, const char *bucket_name,
    const char *object_name, int64_t expires, aos_http_request_t *req);

unsigned long get_file_size(const char *file_path);

int oss_utf8_encode(char **dest, const char *src, int max_src_size);
OSS_CPP_END

#endif
