#! /bin/sh

TARGET="/mnt/mtd/ipc"
DRV_PATH="$TARGET/modules"
CONF="$TARGET/conf"
NETDEV=eth0
WIFIPATH="$CONF/wifi.conf"
. $WIFIPATH
NETINFO=$CONF/config_net.ini
NETPRIV=$CONF/config_priv.ini
PLATFORM=$CONF/config_platform.ini
FDDNS=$CONF/config_facddns.ini

DEF_IPADDR="192.168.1.126"
DEF_GATEWAY="192.168.1.1"

clearRoute()
{
	route del -net 239.0.0.0 netmask 255.0.0.0 eth0
	route del -net 239.0.0.0 netmask 255.0.0.0 ra0
	GATEWAY=`route | grep default | awk -F " " '{printf $2}'`
	route del default gw $GATEWAY
	GIP=`route | grep eth0 | awk -F " " '{printf $1}'`
	GNM=`route | grep eth0 | awk -F " " '{printf $3}'`
	route del -net $GIP netmask $GNM
}

loadwifista()
{
	ifconfig $NETDEV down
	ifconfig $NETDEV up

	iwpriv $NETDEV set AuthMode=$WifiMode
	iwpriv $NETDEV set NetworkType=Infra
	iwpriv $NETDEV set EncrypType=$WifiEnc
	if [ $WifiEnc != "NONE" ]
	then	
		if [ $WifiEnc == "WEP" ]
		then
			iwpriv $NETDEV set DefaultKeyID=1
			iwpriv $NETDEV set Key1="$WifiKey"
		else
			iwpriv $NETDEV set WPAPSK="$WifiKey"
		fi
	fi
	iwpriv $NETDEV set SSID="$WifiSsid"
    $TARGET/updatewifi.sh 10 &
}

loadwifiap()
{
	ifconfig ra0 up
	sleep 4
	TMP=/mnt/mtd/ipc/tmpfs/wf129
	TMP1=/mnt/mtd/ipc/tmpfs/wf129t
	iwpriv ra0 get_site_survey | sed '1d 2d $d' > $TMP
	sleep 1
	iwpriv ra0 get_site_survey | sed '1d 2d $d' > $TMP
	sleep 1
	iwpriv ra0 get_site_survey | sed '1d 2d $d' > $TMP	
	ifconfig ra0 down
	$TARGET/wfsort $TMP $TMP1
	mv $TMP1 $TMP
	rmmod mtnet7601Usta
	rmmod mt7601Usta
	rmmod mtutil7601Usta
	killall updatewifi.sh
	rm /mnt/mtd/ipc/tmpfs/wifi.ok
	insmod /mnt/mtd/ipc/modules/mt7601Uap.ko	
	ifconfig ra0 $DEF_IPADDR netmask 255.255.255.0
	GUUID=`/mnt/mtd/ipc/readcfg $FDDNS "facddnscfg:facusername"`
	WifiSsid="IPCAM-$GUUID"
	iwpriv ra0 set SSID="$WifiSsid"
	udhcpd -f /mnt/mtd/ipc/conf/udhcps/udhcpd.conf &
	route add default gw $DEF_GATEWAY
}

loadNetwork()
{	
    dhcp1=`grep dhcp $NETINFO | awk -F "\"" '{print $2}'`
    ipaddr1=`grep ipaddr $NETINFO | awk -F "\"" '{print $2}'`
    gateway1=`grep gateway $NETINFO | awk -F "\"" '{print $2}'`
    netmask1=`grep netmask $NETINFO | awk -F "\"" '{print $2}'` 

    gat1=`echo $ipaddr1 | awk -F "." '{print $1}'`
    gat2=`echo $ipaddr1 | awk -F "." '{print $2}'`
    gat3=`echo $ipaddr1 | awk -F "." '{print $3}'`
    gat4=`echo $ipaddr1 | awk -F "." '{print $4}'`
    gateway2="$gat1.$gat2.$gat3.1"     	   	
		
	if [ $dhcp1 = "y" ] 
	then
		$TARGET/dhcp.sh $NETDEV
		sleep 5
		return 0
	fi   

	if ! ifconfig $NETDEV $ipaddr1 netmask $netmask1
	then
		ifconfig $NETDEV $DEF_IPADDR netmask 255.255.255.0	
	fi
	
	if ! route add default gw $gateway1
	then
		if ! route add default gw $gateway2
		then
			route add default gw $DEF_GATEWAY
		fi
	fi
		
	killall runarp
	$TARGET/runarp $NETDEV & > /dev/null	
		
	return 0      
}

loadwifi()
{
	if [ $WifiType = "Infra" ]	
	then
		loadwifista
		loadNetwork
	else
		loadwifiap
	fi
}

loadAround()
{
    $TARGET/facddns.sh
    $TARGET/upnpmap.sh
    $TARGET/th3ddns.sh
    $TARGET/loadp2p.sh &
}

killall udhcpc	
killall udhcpd
killall upnp_map
killall tutk
killall dana
killall goolink
killall p2p_obj
sleep 1

if [ $1 -eq 0 ]
then
	NETDEV="eth0"
	ifconfig ra0 down
	if [ $WifiType = "Adhoc" ]
	then
		rmmod mt7601Uap
		insmod $DRV_PATH/mtutil7601Usta.ko
		insmod $DRV_PATH/mt7601Usta.ko
		insmod $DRV_PATH/mtnet7601Usta.ko
	fi
	clearRoute
	ifconfig eth0 down
	ifconfig eth0 up
	loadNetwork
	NETFLAG="0"
else
	NETDEV="ra0"
	clearRoute
	loadwifi
	NETFLAG="1"
fi

echo $NETFLAG > $TARGET/tmpfs/netflag.dat
loadAround
