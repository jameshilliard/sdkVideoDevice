#! /bin/sh

. /mnt/mtd/ipc/conf/wifi.conf
wifidev="ra0"
wifi_res=1

checkwifi()
{
	wifi_res=0
	if [[ $WifiEnc = "NONE" ]] || [[ $WifiEnc = "WEP" ]]
	then
		sleep 2
		for i in $(seq 6)
		do
			sleep 0.5
			if ! iwconfig $wifidev | grep "Access Point:" > /dev/null
			then
				wifi_res=1
				break			
			fi
		done		
	else
		if ! iwconfig $wifidev | grep "Security mode:" > /dev/null
		then
			wifi_res=1
			break			
		fi	
	fi
}

sleep $1

while [ 1 ]
do
	checkwifi
    if [ $wifi_res -eq 1 ]
    then
    	rm /mnt/mtd/ipc/tmpfs/wifi.ok 2> /dev/null
    else
    	touch /mnt/mtd/ipc/tmpfs/wifi.ok
    fi
    sleep 60
done
