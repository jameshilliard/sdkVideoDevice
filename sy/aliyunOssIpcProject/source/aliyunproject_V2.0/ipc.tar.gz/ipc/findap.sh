#! /bin/sh

TARGET="/mnt/mtd/ipc"
CONF="$TARGET/conf"
WIFIPATH="$CONF/wifi.conf"
TMP=/mnt/mtd/ipc/tmpfs/wf129
TMP1=/mnt/mtd/ipc/tmpfs/wf129t
NETDEV=ra0
PLAT=$CONF/config_devtype.ini
. $WIFIPATH

ptype=`grep type $PLAT | awk -F "\"" '{print $2}'`
if [ $ptype -eq 6 ]
then
	exit 0
fi

if ! ifconfig | grep ra0 > /dev/null
then
   	ifconfig ra0 up
    sleep 4
    iwpriv ra0 get_site_survey | sed '1d 2d $d' > $TMP    
    ifconfig ra0 down
    $TARGET/wfsort $TMP $TMP1
    mv $TMP1 $TMP
    exit 0
fi

if [ $WifiType = "Adhoc" ]
then
	exit 0
fi

sleep 1
iwpriv ra0 get_site_survey | sed '1d 2d $d' > $TMP
$TARGET/wfsort $TMP $TMP1
mv $TMP1 $TMP
