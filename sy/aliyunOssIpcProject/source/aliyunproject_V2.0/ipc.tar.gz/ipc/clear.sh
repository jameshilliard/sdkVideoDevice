#! /bin/sh

IPC_PATH="/mnt/mtd/ipc"
LIB_PATH="/lib"

#szy
rm -fr $IPC_PATH/libs
rm -fr $LIB_PATH/libboost_chrono.so.1.50.0
rm -fr $LIB_PATH/libboost_filesystem.so.1.50.0
rm -fr $LIB_PATH/libboost_system.so.1.50.0
rm -fr $LIB_PATH/libboost_thread.so.1.50.0
rm -fr $LIB_PATH/libszySDK.so

#sync
