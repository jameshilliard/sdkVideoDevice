/** Automatically generated file. DO NOT MODIFY */
package com.tutk.P2PCamLive.Deluxe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}