package com.tutk.customized.command;

import com.tutk.IOTC.AVIOCTRLDEFs;

public class CustomCommand  extends AVIOCTRLDEFs{
	
	/**
	 * For Customized Project command define
	 */

}
