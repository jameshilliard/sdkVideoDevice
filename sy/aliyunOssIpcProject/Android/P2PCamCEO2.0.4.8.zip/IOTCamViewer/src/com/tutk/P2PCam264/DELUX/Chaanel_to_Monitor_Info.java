package com.tutk.P2PCam264.DELUX;

public class Chaanel_to_Monitor_Info {

	public String UUID;
	public String NickName;
	public String UID;
	public int ChannelIndex;
	public String ChannelName;
	public int MonitorIndex;

	public Chaanel_to_Monitor_Info(String uuid,String nickname,String uid,int channelIndex,String channelName,int monitorindex) 
	{

		UUID = uuid;
		NickName = nickname;
		UID = uid;
		ChannelIndex = channelIndex;
		ChannelName = channelName;
		MonitorIndex = monitorindex;

	}
}
