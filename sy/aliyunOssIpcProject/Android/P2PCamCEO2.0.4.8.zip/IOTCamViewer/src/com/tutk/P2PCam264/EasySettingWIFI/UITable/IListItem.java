package com.tutk.P2PCam264.EasySettingWIFI.UITable;

public interface IListItem {

	public boolean isClickable();
	
	public void setClickable(boolean clickable);
	
}
