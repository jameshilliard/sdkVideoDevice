﻿// JavaScript Document
function load_form_uienable()
{
	var f1 = document.getElementById("form_uienable1");
	var f0 = document.getElementById("form_uienable0");
	
	if (ui_enable == "1")
		f1.checked = true;
	else
		f0.checked = true;
}

function change_form_uienable()
{
	var f = document.getElementById("form_uienable1");
	var i;
	
	if(f.checked == true)
	{
		for (i = 0; i <= 4; i++)
		{
       		document.getElementById('layer' + i).style.visibility = "visible";
   		}
	}
	else
	{
		for (i = 0; i <= 4; i++)
		{
       		document.getElementById('layer' + i).style.visibility = "hidden";
   		}
	}
}

function submit_form_uienable()
{
	var f = document.getElementById("form_uienable1");
	var s = document.getElementById("form_submit");
	
	if (f.checked == true)
		s.ui_enable.value = 1;
	else
		s.ui_enable.value = 0;
		
	
}

function load_form_uiname()
{
	var f = document.getElementById("form_uiname");
	
	f.value = ui_cname;
}

function check_form_uiname()
{
	var f = document.getElementById("form_uiname");

	/*if (f.value == "")
	{
		alert(str_note_inputusername);
		return false;
	}
	else
	{
		if (checkHankakuNoKana(f.value, f, str_err_username + comma + str_err_invaildc) == false)
			return false;
		if (checkProhibitedCharacter(f.value) == false)
			return false;	
	}*/
	if(checkProhibitedCharacter2(f,f.value)==false)return false;
	
	return true;
}

function submit_form_uiname()
{
	var f = document.getElementById("form_uiname");
	var s = document.getElementById("form_submit");

	s.ui_cname.value = f.value;	
	
}

function load_form_uipasswd()
{
	var f = document.getElementById("form_uipasswd");

	f.value = ui_cpasswd;
}

function check_form_uipasswd()
{
	var f = document.getElementById("form_uipasswd");

	/*if (f.value == "")
	{
		alert(str_note_inputpassword);
		return false;
	}
	else
	{
		if (checkHankakuNoKana(f.value, f, str_err_password + comma + str_err_invaildc) == false)
			return false;
		if (checkProhibitedCharacter(f.value) == false)
			return false;	
	}*/
	if(checkProhibitedCharacter2(f,f.value)==false)return false;
	
	return true;
}

function submit_form_uipasswd()
{
	var f = document.getElementById("form_uipasswd");
	var s = document.getElementById("form_submit");
	
	s.ui_cpasswd.value = f.value;
	
}

function load_form_uiport()
{
	var f = document.getElementById("form_uiport");
	
	f.value = ui_port;	
}

function check_form_uiport()
{
	var f = document.getElementById("form_uiport");
	
	if (f.value == "")
	{
		alert(str_note_inputport);
		f.select();
		return false;
	}
	
	var j;
	var portvalue = f.value;
	
	for (j = 0; j < (portvalue.length); j++)
	{
		var ch = portvalue.substring(j, j + 1);
		if ("0" > ch || ch > "9") 
		{
			alert(str_err_invaildc + period);
			f.select();
			return false;
		}
	}

	if ((f.value < 1 ) || (f.value > 65535))
	{
		alert(str_err_port + comma + str_1_65535);
		f.select();
		return false;
	}
	
	return true;
}

function submit_form_uiport()
{
	var f = document.getElementById("form_uiport");
	var s = document.getElementById("form_submit");

	s.ui_port.value = f.value;	
	
}

function load_form_uiserver()
{
	var f = document.getElementById("form_uiserver");

	f.value = ui_server;
}

function check_form_uiserver()
{
	var f = document.getElementById("form_uiserver");

/*	if (f.value == "")
	{
		alert(str_note_inputservaddr);
		f.focus();
		return false;
	}									
	else
	{
		if (checkProhibitedCharacterUser(f.value) == false)
		{
			f.focus();
			return false;
		}
		
		if (checkHankakuNoKana(f.value, f, str_err_servaddr + comma + str_err_invaildc)==false)
		{
			f.focus();
			return false;
		}
			
	}*/
	if(checkProhibitedCharacter2(f,f.value)==false)return false;

	return true;
}

function submit_form_uiserver()
{
	var f = document.getElementById("form_uiserver");
	var s = document.getElementById("form_submit");
	
	s.ui_server.value = f.value;
	
}

function load_form_uidevname()
{
	var f = document.getElementById("form_uidevname");
	
	f.value = ui_devname;
}

function check_form_uidevname()
{
	var f = document.getElementById("form_uidevname");

	/*if (f.value == "")
	{
		alert(str_note_inputusername);
		return false;
	}
	else
	{
		if (checkHankakuNoKana(f.value, f, str_err_username + comma + str_err_invaildc) == false)
			return false;
		if (checkProhibitedCharacter(f.value) == false)
			return false;	
	}*/
	if(checkProhibitedCharacter2(f,f.value)==false)return false;
	
	return true;
}

function submit_form_uidevname()
{
	var f = document.getElementById("form_uidevname");
	var s = document.getElementById("form_submit");

	s.ui_devname.value = f.value;	
	
}