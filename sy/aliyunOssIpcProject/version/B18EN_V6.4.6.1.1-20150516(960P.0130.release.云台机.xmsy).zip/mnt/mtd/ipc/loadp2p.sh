#! /bin/sh

MAPINI="/mnt/mtd/ipc/conf/config_platform.ini"

sleep 3

hichipenable=`grep hichipenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $hichipenable -eq 1 ]
then
	killall hidog
	killall hichip
    /mnt/mtd/ipc/hidog &
fi

tenable=`grep tenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $tenable -eq 1 ]
then
	killall tutk
    /mnt/mtd/ipc/tutk &
fi

objenable=`grep objenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $objenable -eq 1 ]
then
	killall p2p_obj
    /mnt/mtd/ipc/p2p_obj &
fi

genable=`grep genable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $genable -eq 1 ]
then
	killall goolink
    /mnt/mtd/ipc/goolink &
fi

danaenable=`grep danaenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $danaenable -eq 1 ]
then
	killall dana
    /mnt/mtd/ipc/dana &
fi
