#! /bin/sh

while [ 1 ]
do
	sleep 90
	
	if NUM=`netstat -np | grep danap2p | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 10 ]
		then
			killall -9 danap2p
		fi
	fi
	sleep 5
	
	if NUM=`netstat -np | grep ipc_server | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall ipc_server
			sleep 1
			killall ipc_server			
		fi
	fi	
	sleep 5

	if NUM=`netstat -np | grep onvif | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall -9 onvif
			sleep 1
			killall -9 onvif
			sleep 3
			/mnt/mtd/ipc/tmpfs/onvif &			
		fi
	fi
	sleep 5	

	if NUM=`netstat -np | grep proxy | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall -9 proxy
			sleep 1
			killall -9 proxy
			sleep 3
			/mnt/mtd/ipc/proxy &			
		fi
	fi
	sleep 5	
	
	if NUM=`netstat -np | grep tutk | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall -9 tutk
			sleep 1
			killall -9 tutk
			sleep 3
			/mnt/mtd/ipc/tutk &			
		fi
	fi
	sleep 5	

	if NUM=`netstat -np | grep goolink | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall -9 goolink
			sleep 1
			killall -9 goolink
			sleep 3
			/mnt/mtd/ipc/goolink &			
		fi
	fi
	sleep 5		

	if NUM=`netstat -np | grep p2p_obj | grep CLOSE_WAIT | wc -l`
	then
		if [ $NUM -gt 5 ]
		then
			killall -9 p2p_obj
			sleep 1
			killall -9 p2p_obj
			sleep 3
			/mnt/mtd/ipc/p2p_obj &			
		fi
	fi
	sleep 5			
		
done
