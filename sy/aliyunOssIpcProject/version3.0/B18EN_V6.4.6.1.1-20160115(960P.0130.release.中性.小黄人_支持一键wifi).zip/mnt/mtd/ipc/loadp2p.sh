#! /bin/sh

MAPINI="/mnt/mtd/ipc/conf/config_platform.ini"

sleep $1

tenable=`grep tenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $tenable -eq 1 ]
then
	killall tutk
    /mnt/mtd/ipc/tutk &
fi

objenable=`grep objenable $MAPINI | awk -F "\"" '{print $2}'` 
if [ $objenable -eq 1 ]
then
	killall p2p_obj
    /mnt/mtd/ipc/p2p_obj &
fi
