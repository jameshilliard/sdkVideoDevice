#! /bin/sh

SPEED=54
POWER=1
CHN=1
MCS=7
MODE=1
BW=0

set_tx_mode0()
{
	iwpriv ra0 set ATE=ATESTART
	iwpriv ra0 set ATECHANNEL=$CHN
	iwpriv ra0 set ATETXMODE=$MODE
	iwpriv ra0 set ATETXMCS=$MCS	
	iwpriv ra0 set ATETXBW=$BW	
	iwpriv ra0 set ATETXCNT=100000000
	iwpriv ra0 set ATETXFREQOFFSET=0
	iwpriv ra0 set ATE=TXFRAME
	iwpriv ra0 set ATE=TXCARR	 
	iwpriv ra0 set ATETXPOW0=$POWER
	iwpriv ra0 set ATETXPOW1=$POWER
	iwpriv ra0 set ATETXFREQOFFSET=145
}	

set_tx_mode1()
{
	iwpriv ra0 set ATE=ATESTART
	iwpriv ra0 set ATECHANNEL=$CHN
	iwpriv ra0 set ATETXMODE=$MODE
	iwpriv ra0 set ATETXMCS=$MCS	
	iwpriv ra0 set ATETXBW=$BW	
	iwpriv ra0 set ATETXCNT=100000000
	iwpriv ra0 set ATETXFREQOFFSET=0
	iwpriv ra0 set ATE=TXFRAME	 
	iwpriv ra0 set ATETXPOW0=$POWER
	iwpriv ra0 set ATETXPOW1=$POWER
	iwpriv ra0 set ATETXFREQOFFSET=145
}

set_rx_mode()
{	
	iwpriv ra0 set ATE=ATESTART
	iwpriv ra0 set ATECHANNEL=$CHN
	iwpriv ra0 set ResetCounter=1
	iwpriv ra0 set ATETXFREQOFFSET=145		
	iwpriv ra0 set ATETXMODE=$MODE
	iwpriv ra0 set ATETXMCS=$MCS			
	iwpriv ra0 set ATETXBW=$BW
	iwpriv ra0 set ATE=RXFRAME
}

SPEED=$2
CHN=$3
#POWER=$4

case $SPEED in
	1)
		MODE=0
		MCS=0	
		;;
	2)
		MODE=0
		MCS=1
		;;	
	5)
		MODE=0
		MCS=2
		;;
	11)
		MODE=0
		MCS=3
		;;	
	6)
		MODE=1
		MCS=0
		;;
	9)
		MODE=1
		MCS=1
		;;	
	12)
		MODE=1
		MCS=2
		;;
	18)
		MODE=1
		MCS=3
		;;
	24)
		MODE=1
		MCS=4
		;;
	36)
		MODE=1
		MCS=5
		;;
	48)
		MODE=1
		MCS=6
		;;	
	54)
		MODE=1
		MCS=7
		;;
	13)
		MODE=2
		MCS=1
		;;	
	19)
		MODE=2
		MCS=2
		;;
	26)
		MODE=2
		MCS=3
		;;	
	39)
		MODE=2
		MCS=4
		;;
	52)
		MODE=2
		MCS=5
		;;	
	58)
		MODE=2
		MCS=6
		;;	
	65)
		MODE=2
		MCS=7
		;;	
	78)
		MODE=2
		MCS=12
		;;	
	104)
		MODE=2
		MCS=13
		;;
	117)
		MODE=2
		MCS=14
		;;
	130)
		MODE=3
		MCS=7
		;;
	300)
		MODE=3
		MCS=7
		BW=1
		;;																																			
esac

ifconfig ra0 up

if [ $1 -eq 0 ]
then
	set_tx_mode0
	sleep 1
	set_tx_mode0
fi

if [ $1 -eq 1 ]
then
	set_tx_mode1
	sleep 1
	set_tx_mode1
fi

if [ $1 -eq 2 ]
then
	set_rx_mode
	sleep 1
	set_rx_mode
fi
