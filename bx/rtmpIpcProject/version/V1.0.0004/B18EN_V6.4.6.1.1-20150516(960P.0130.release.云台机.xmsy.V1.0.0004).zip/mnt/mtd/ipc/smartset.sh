#! /bin/sh

killall smartset
sleep $1
/mnt/mtd/ipc/smartset &
