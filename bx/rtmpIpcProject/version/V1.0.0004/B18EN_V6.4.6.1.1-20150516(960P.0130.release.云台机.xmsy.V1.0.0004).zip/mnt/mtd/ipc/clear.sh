#! /bin/sh

IPC_PATH="/mnt/mtd/ipc"

rm -fr $IPC_PATH/goolink
rm -fr $IPC_PATH/dana
rm -fr $IPC_PATH/danap2p
rm -fr $IPC_PATH/modules/mt7601Uap.ko

#sync
