#! /bin/sh

TARGET="/mnt/mtd/ipc"
DRV_PATH="$TARGET/modules"
CONF="$TARGET/conf"
NETDEV=eth0
WIFIPATH="$CONF/wifi.conf"
. $WIFIPATH
NETINFO=$CONF/config_net.ini
NETPRIV=$CONF/config_priv.ini

DEF_IPADDR="192.168.1.88"
DEF_GATEWAY="192.168.1.1"

clearRoute()
{
	GATEWAY=`route | grep default | awk -F " " '{printf $2}'`
	route del default gw $GATEWAY
	GIP=`route | grep eth0 | awk -F " " '{printf $1}'`
	GNM=`route | grep eth0 | awk -F " " '{printf $3}'`
	route del -net $GIP netmask $GNM
	GIP=`route | grep ra0 | awk -F " " '{printf $1}'`
	GNM=`route | grep ra0 | awk -F " " '{printf $3}'`
	route del -net $GIP netmask $GNM	
}

setRoute()
{
	ipaddr1=`ifconfig $NETDEV | grep "inet addr:" | awk '{printf $2}' | awk -F ":" '{printf $2}'`
    gat1=`echo $ipaddr1 | awk -F "." '{print $1}'`
    gat2=`echo $ipaddr1 | awk -F "." '{print $2}'`
    gat3=`echo $ipaddr1 | awk -F "." '{print $3}'`
    routeway1="$gat1.$gat2.$gat3.0" 
    route add -net $routeway1 netmask 255.255.255.0 $NETDEV
}

loadwifista()
{
	iwpriv $NETDEV set AuthMode=$WifiMode
	iwpriv $NETDEV set NetworkType=Infra
	iwpriv $NETDEV set EncrypType=$WifiEnc
	if [ $WifiEnc != "NONE" ]
	then	
		if [ $WifiEnc == "WEP" ]
		then
			iwpriv $NETDEV set DefaultKeyID=1
			iwpriv $NETDEV set Key1="$WifiKey"
		else
			iwpriv $NETDEV set WPAPSK="$WifiKey"
		fi
	fi
	iwpriv $NETDEV set SSID="$WifiSsid"
    $TARGET/updatewifi 10 &
}

loadNetwork()
{	
    dhcp1=`grep dhcp $NETINFO | awk -F "\"" '{print $2}'`
    ipaddr1=`grep ipaddr $NETINFO | awk -F "\"" '{print $2}'`
    gateway1=`grep gateway $NETINFO | awk -F "\"" '{print $2}'`
    netmask1=`grep netmask $NETINFO | awk -F "\"" '{print $2}'` 

    gat1=`echo $ipaddr1 | awk -F "." '{print $1}'`
    gat2=`echo $ipaddr1 | awk -F "." '{print $2}'`
    gat3=`echo $ipaddr1 | awk -F "." '{print $3}'`
    gat4=`echo $ipaddr1 | awk -F "." '{print $4}'`
    gateway2="$gat1.$gat2.$gat3.1"     	   	
		
	if [ $dhcp1 = "y" ] 
	then
		$TARGET/dhcp.sh $NETDEV
		sleep 5
		return 0
	fi   

	if ! ifconfig $NETDEV $ipaddr1 netmask $netmask1
	then
		ifconfig $NETDEV $DEF_IPADDR netmask 255.255.255.0	
	fi
	
	if ! route add default gw $gateway1
	then
		if ! route add default gw $gateway2
		then
			route add default gw $DEF_GATEWAY
		fi
	fi
		
	killall runarp
	$TARGET/runarp $NETDEV & > /dev/null	
		
	return 0      
}

loadwifi()
{
	if [ $WifiType = "Infra" ]	
	then
		loadwifista
		loadNetwork
	else
		$TARGET/smartset.sh 5 &
	fi
}

loadAround()
{
    $TARGET/facddns.sh
    $TARGET/upnpmap.sh
    $TARGET/th3ddns.sh
#    $TARGET/loadp2p.sh &
}

NETFL=`cat /mnt/mtd/ipc/tmpfs/netchg`
killall udhcpc	
killall udhcpd
killall upnp_map
killall smartset
killall updatewifi
rm /mnt/mtd/ipc/tmpfs/wifi.ok 2> /dev/null
#killall hidog
#killall hichip
#killall tutk
#killall p2p_obj
#killall goolink
#killall dana
sleep 1

if [ $NETFL -eq 0 ]
then
	iwpriv ra0 set SSID=""
	NETDEV="eth0"
	clearRoute
	setRoute
	loadNetwork
	NETFLAG="0"	
else
	NETDEV="ra0"
	clearRoute
	setRoute
	loadwifi
	NETFLAG="1"
fi

echo $NETFLAG > $TARGET/tmpfs/netflag.dat

loadAround

rm -f /mnt/mtd/ipc/tmpfs/netchg
