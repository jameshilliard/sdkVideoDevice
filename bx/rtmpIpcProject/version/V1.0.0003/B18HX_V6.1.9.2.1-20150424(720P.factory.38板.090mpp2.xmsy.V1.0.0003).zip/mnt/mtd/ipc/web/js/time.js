﻿// JavaScript Document
function load_form_stime()
{
	var f = document.getElementById("form_stime");
	         
        f.innerHTML = address;
}

