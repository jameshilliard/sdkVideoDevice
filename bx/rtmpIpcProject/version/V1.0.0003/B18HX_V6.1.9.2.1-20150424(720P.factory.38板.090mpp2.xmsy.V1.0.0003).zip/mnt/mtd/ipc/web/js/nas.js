﻿// JavaScript Document

function login()
{
window.open("https://www.dropbox.com");
}

function authorize()
{
window.open("https://www.dropbox.com/1/oauth2/authorize?response_type=code&client_id=rgwl2xro2dn5xgs");
}

function load_form_cs_username()
{
      var f = document.getElementById("form_cs_username");
      f.value = cs_username;
}

function load_form_cs_password()
{
	var f  = document.getElementById("form_cs_password");
	f.value  = cs_password;
	
}

function load_form_cs_requesttoken()
{
	var f  = document.getElementById("form_cs_requesttoken");
	f.value  = cs_requesttoken;
	
}

function submit_form_cs_username()
{
	var f = document.getElementById("form_cs_username");
	var s = document.getElementById("form_submit");
	
	s.cs_username.value = f.value;
}

function submit_form_cs_password()
{
	var f = document.getElementById("form_cs_password");
	var s = document.getElementById("form_submit");
	
	s.cs_password.value = f.value;

}

function submit_form_cs_requesttoken()
{
	var f = document.getElementById("form_cs_requesttoken");
	var s = document.getElementById("form_submit");
	
	s.cs_requesttoken.value = f.value;

}

function load_form_cs_type()
{
	var f = document.getElementById("form_cs_type");

	f.options[cs_type].selected=true;	
}


function submit_form_cs_type()
{
	var f = document.getElementById("form_cs_type");
	var s = document.getElementById("form_submit");
	
	s.cs_type.value = f.selectedIndex;
}